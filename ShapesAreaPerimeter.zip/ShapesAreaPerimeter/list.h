#pragma once
#include <iostream>
#include <string>
#include "shapes.h"
#include "square.h"
#include "circle.h"
#include "ellipsis.h"
#include "poligon.h"
#include "rectangle.h"
#include "triangle.h"

using namespace std;

class List {

private:

	Shapes* shapeList[];

public:

	void fillShapeList() {

		shapeList[0] = new Square();
		shapeList[1] = new Circle();
		shapeList[2] = new Ellipsis();
		shapeList[3] = new Poligon();
		shapeList[4] = new Rectangle();
		shapeList[5] = new Triangle();

	}

	void showShapeList() {

		for (int i = 0; i < 6; i++) {

			cout << shapeList[i]->getDetails() << endl;

		}


	}

};