#pragma once
#include "shapes.h"

class Circle : public Shapes {

private:

	string name = "Circulo";
	double radio = 2;

public:

	double calculateArea() {

		double area = 3.14 * radio + radio;
		return area;

	}

	double calculatePerimeter() {

		double perimeter = 3.14 * 2 * radio;
		return perimeter;

	}

	string getDetails() {

		string details = name + " tiene perimetro " + to_string(calculatePerimeter()) + " y area " + to_string(calculateArea());
		return details;

	}

};