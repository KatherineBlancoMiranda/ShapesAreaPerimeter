#pragma once
#include <iostream>
#include <string>

using namespace std;

class Shapes {

private:

	string name;

public:

	virtual double calculateArea() = 0;

	virtual double calculatePerimeter() = 0;

	virtual string getDetails() {
		return "";
	}

};