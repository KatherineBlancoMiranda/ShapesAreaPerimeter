#pragma once
#include "circle.h"
#include <math.h>

class Ellipsis : public Circle {

private:

	string name = "Elipse";
	double radio = 2;
	double majorRadio = 4;

public:

	double calculateArea() {

		double area = 3.14 * radio * majorRadio;
		return area;

	}

	double calculatePerimeter() {

		double perimeter = 2 * 3.14 * sqrt((radio * radio + majorRadio * majorRadio) / 2);
		return perimeter;

	}

	string getDetails() {

		string details = name + " tiene perimetro " + to_string(calculatePerimeter()) + " y area " + to_string(calculateArea());
		return details;

	}

};