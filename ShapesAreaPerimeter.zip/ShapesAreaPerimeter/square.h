#pragma once
#include "shapes.h"

class Square : public Shapes {

private:

	string name = "Cuadrado";
	double base = 2;

public:

	double calculateArea() {

		double area = base * base;
		return area;

	}

	double calculatePerimeter() {

		double perimeter = base * 4;
		return perimeter;

	}

	string getDetails() {

		string details = name + " tiene perimetro " + to_string(calculatePerimeter()) + " y area " + to_string(calculateArea());
		return details;

	}

};