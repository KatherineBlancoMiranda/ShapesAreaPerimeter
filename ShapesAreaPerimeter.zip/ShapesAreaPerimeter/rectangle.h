#pragma once
#include "square.h"

class Rectangle : public Square {

private:

	string name = "Rectangulo";
	double base = 2;
	double high = 3;

public:

	double calculateArea() {

		double area = base * high;
		return area;

	}

	double calculatePerimeter() {

		double perimeter = base * 2 + high * 2;
		return perimeter;

	}

	string getDetails() {

		string details = name + " tiene perimetro " + to_string(calculatePerimeter()) + " y area " + to_string(calculateArea());
		return details;

	}

};