#pragma once
#include "shapes.h"

class Poligon : public Shapes {

private:

	string name = "Poligono";
	double sideLenght = 2;
	double apothem = 3;
	int sides = 5;

public:

	double calculateArea() {

		double area = (calculatePerimeter() * apothem) / 2;
		return area;

	}

	double calculatePerimeter() {

		double perimeter = sideLenght * sides;
		return perimeter;

	}

	string getDetails() {

		string details = name + " tiene perimetro " + to_string(calculatePerimeter()) + " y area " + to_string(calculateArea());
		return details;

	}

};