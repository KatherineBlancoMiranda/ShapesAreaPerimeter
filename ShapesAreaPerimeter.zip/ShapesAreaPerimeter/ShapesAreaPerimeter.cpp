#include <iostream>
#include "list.h"
#include "shapes.h"

int main()
{

	List listOfShapeDetails;
	listOfShapeDetails.fillShapeList();
	listOfShapeDetails.showShapeList();
  
}