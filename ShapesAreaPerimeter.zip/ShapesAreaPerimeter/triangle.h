#pragma once
#include "shapes.h"

class Triangle : public Shapes {

private:

	string name = "Triangulo";
	double base = 4;
	double high = 2.8;
	double side1 = 2;
	double side2 = 2;

public:

	double calculateArea() {

		double area = (base * high) / 2;
		return area;

	}

	double calculatePerimeter() {

		double perimeter = side1 + side2 + base;
		return perimeter;

	}

	string getDetails() {

		string details = name + " tiene perimetro " + to_string(calculatePerimeter()) + " y area " + to_string(calculateArea());
		return details;

	}

};